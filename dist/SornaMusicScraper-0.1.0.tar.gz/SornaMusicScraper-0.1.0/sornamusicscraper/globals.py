
class Globals:
    def __init__(self):
        self.HomePageHeader = {
            'authority': 'sornamusic.ir',
            'method': 'GET',
            'path': '/',
            'scheme': 'https',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'accept-encoding': 'gzip, deflate, br',
            'accept-language': 'en-US,en;q=0.9',
            'cache-control': 'max-age=0',
            'cookie': '_gid=GA1.2.1693925440.1647243151; analytics_campaign={%22source%22:%22direct%22%2C%22medium%22:null}; analytics_token=870871be-186c-1fdc-b820-03a2bc97fd62; yektanet_session_last_activity=3/14/2022; _yngt_iframe=1; _yngt_match={%22sabavision%22:1}; _yngt=6d9cd3be-e8826-675e6-6699e-e1db0e8014e70; content-view-yn-footer-sticky-63446=3; content-view-yn-notification-63448=3; _ga=GA1.2.1435441735.1647243150; _ga_0EJGSDXMYQ=GS1.1.1647243149.1.1.1647243765.0',
            'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="99", "Google Chrome";v="99"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.51 Safari/537.36',
        }
