
import requests
from bs4 import BeautifulSoup

from .req import Req
from .sornamusicscraper import SornaMusicScraper
from .bs import Bs